# WIZ Java Sample Project

Spring WIZ runtime에서 실행되는 Java backend 샘플 프로젝트입니다. 기존 `wiz-sample-project`의 frontend/App 구조는 유지하고, Python `api.py`, controller, model backend는 app-local `api.java`와 Java Struct/domain source로 포팅했습니다.

## Demo Accounts

| Email | Password | Name | Role |
| --- | --- | --- | --- |
| admin@example.com | admin1234 | 관리자 | admin |
| alice@example.com | alice1234 | Alice Kim | user |
| bob@example.com | bob12345 | Bob Park | user |
| carol@example.com | carol123 | Carol Lee | editor |
| dave@example.com | dave1234 | Dave Choi | viewer |

The Java Struct layer seeds these accounts and starter posts idempotently on first API access.

## Source Layout

```text
src/
  app/
    page.access/api.java
    page.dashboard/api.java
    page.members/api.java
    page.mypage/api.java
  controller/
    BaseController.java
    UserController.java
    AdminController.java
  model/
    Struct.java
    struct/UserStruct.java
    db/UserEntity.java
  portal/post/
    app/list/api.java
    app/detail/api.java
    model/PostStruct.java
    model/struct/PostService.java
    model/struct/CommentService.java
    model/db/PostEntity.java
    model/db/CommentEntity.java
```

Frontend files such as `view.pug`, `view.ts`, `view.scss`, `app.json`, `src/angular/**`, and portal frontend assets are preserved from the original sample.

## Run With Spring WIZ

```bash
cd /root/workspace/wiz-java
./wiz-spring/mvnw -f wiz-spring/pom.xml test

tmp=/tmp/wiz-java-sample
rm -rf "$tmp"
java -jar wiz-spring/target/wiz-spring-*.jar create "$tmp"
java -jar wiz-spring/target/wiz-spring-*.jar project create --root "$tmp" --project main --path /root/workspace/wiz-java/wiz-sample-project-java
java -jar wiz-spring/target/wiz-spring-*.jar project build --root "$tmp" --project main --clean
java -jar wiz-spring/target/wiz-spring-*.jar run --root "$tmp" --port 8080
```

Main API smoke:

```bash
curl -i -c /tmp/wiz-cookie.txt -X POST http://127.0.0.1:8080/wiz/api/page.access/login \
  -d 'email=admin@example.com&password=admin1234'
curl -i -b /tmp/wiz-cookie.txt -X POST http://127.0.0.1:8080/wiz/api/page.dashboard/overview
curl -i http://127.0.0.1:8080/wiz/api/portal.post.list/search?page=1\&dump=5
```

## Implemented APIs

- `POST /wiz/api/page.access/login`
- `POST /wiz/api/page.dashboard/overview`
- `GET|POST /wiz/api/page.members/list`
- `POST /wiz/api/page.members/invite`
- `GET|POST /wiz/api/page.members/detail`
- `POST /wiz/api/page.members/remove`
- `GET|POST /wiz/api/page.mypage/get`
- `POST /wiz/api/page.mypage/update_profile`
- `POST /wiz/api/page.mypage/change_password`
- `GET|POST /wiz/api/portal.post.list/categories`
- `GET|POST /wiz/api/portal.post.list/search`
- `GET|POST /wiz/api/portal.post.detail/get`
- `POST /wiz/api/portal.post.detail/save`
- `POST /wiz/api/portal.post.detail/delete`

The `page.dashboard`, `page.members`, and `page.mypage` apps use the built-in `user` controller guard and require a session `id`. The post portal apps keep the original `base` controller metadata and populate author information from the current session when it is present.